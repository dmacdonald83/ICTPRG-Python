words = input("Enter some words: ")
print("You entered", len(words.split()), "words.")
